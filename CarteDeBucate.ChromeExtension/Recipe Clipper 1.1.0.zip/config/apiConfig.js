// Local
//export const API_BASE_URL = "https://localhost:7080";

// Render
export const API_BASE_URL = "https://cartedebucate.onrender.com";

export const API_ENDPOINTS = {
    recipes: `${API_BASE_URL}/api/recipes`,
    recipeExists: `${API_BASE_URL}/api/recipes/exists`,
    currentUser: `${API_BASE_URL}/api/authentication/me`,
    exchangeCode: `${API_BASE_URL}/api/authentication/exchange-code`,
    mvcLogin: `${API_BASE_URL}/Account/Login`
};
